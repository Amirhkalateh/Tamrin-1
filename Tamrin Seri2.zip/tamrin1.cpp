#include <iostream>
#include <conio.h>
#include <math.h>
using namespace std;

int main ()
{
	float A , B , fact , answer = 0 ;
	long double Factorial1 = 1 ,Factorial2 = 1 ;
	char c ;
	cout << "Please enter your calculation!\n" ;
	cin >> A >> c >> B ;
	
	if (c=='*')
	{
		answer = A*B ;
		cout << A << "*" << B << "= " << answer ;
	}
	
	else if (c=='/')
	{
		cout << "\n\n" << "Radical " << A << " = " << sqrt(A);
		cout << "\n\n" << "Radical " << B << " = " << sqrt(B);
	}
	
	else if (c=='+')
	{
		for (int i = 1 ; i<= A && i <= B ; i++)
		{
			Factorial1 = i * Factorial1;
		}
		
		for (int i = 1 ; i <= B ; i++)
		{
			Factorial2 = i * Factorial2;
		}
		cout << "Factorial  " << A << " = " << Factorial1 << endl ;
		cout << "Factorial  " << B << " = " << Factorial2 << endl ;
	}
	
	return 0 ;
	
}
