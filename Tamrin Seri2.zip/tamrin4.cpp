#include <iostream>
#include <conio.h>
#include <math.h>
using namespace std;

int main ()
{
	float grade , sum = 0 , average = 0 ;
	int FN , LN ;
	cout << "First Name : " ;
	cin >> FN ;
	cout << " Last Name : " ;
	cin >> LN ;
	for (int i = 1 ; i <= 3 ; i++)
	{
		cout << "namrat ra vared konid : " ;
		cin >> grade ;
		sum = sum + grade ;
	}
	average = sum / 3 ;
	cout << average << endl;
	if (average > 17)
	cout << "Great. " ;
	else if (12<= average && average <17)
	cout << "Normal. " ;
	else if (average < 12)
	cout << "Fail. " ;
	return 0;

}
