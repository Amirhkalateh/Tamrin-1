#include <iostream>
#include <conio.h>
#include <math.h>
using namespace std;

int main()
{
	float vazn , ghad ,BMI = 0 ;
	cout << "vazn khod ra vared konid Be(Kiloo Gram) : " ;
	cin >> vazn ;
	cout << "ghad khod ra vared konid Be(Metr) : " ;
	cin >> ghad ;
	BMI = (vazn / ( ghad * ghad ));
	cout << "BMI = " << BMI << endl ;
	if (BMI <= 18.5)
	cout << "UNDERWEIGHT " ;
	else if (18.5 < BMI && BMI < 24.9)
	cout << "NORMAL " ;
	else if (25 < BMI && BMI < 29.9)
	cout << "OVERWEIGHT " ;
	else if (30 < BMI && BMI < 34.9)
	cout << "OBESE " ;
	else if (35 < BMI)
	cout << "EXTREMELY OBESE " ;
	return 0;
}
